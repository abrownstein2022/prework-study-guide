# Prework Study Guide Webpage

## Description

This Prework Study Guide was created for boot camp students who were going through the Prework. It contains notes on HTML, CSS, Git, and JavaScript.

This project helped me to gain knowledge on website creation using the latest tools.  It was challenging but helped me learn about git, github and VS Code so I can eventually become a full-stack web developer.

## Installation

N/A

## Usage

This website was formatted to make it easy to read. 

To use this Prework Study Guide, you can review the notes in each section. For suggestions on what to study first, open the Chrome DevTools by pressing Command+Option+I (macOS) or Control+Shift+I (Windows). A console panel should open either below or to the side of the webpage in the browser. There you will see a list of topics we learned from the prework along with a suggestion on which topic to study first.

## Credits

N/A

## License

The last section of a high-quality README file is the license. This lets other developers know what they can and cannot do with your project. If you need help choosing a license, refer to [https://choosealicense.com/](https://choosealicense.com/).

---

## Badges

N/A

## Features

N/A

## How to Contribute

N/A

## Tests

N/A